from interruptingcow import timeout
from os.path import join as path_join

class LinuxShell:
    def __init__(self, user, timeout = None):
        self.user = user
        self.pwd = ""
        self.stdout_timeout = timeout or 10
        self.isWorking = False
        self.machine = f"{self.user}@machine:/home/{self.user}# "
        self.configure()

    def stdin(self):
        return input(self.machine)

    def stdout(self):
        return None

    def configure(self):
        runtime_error = False
        if not self.isWorking:
            try:
                with timeout(self.stdout_timeout, exception=RuntimeError):
                    self.stdout("pwd")
                    self.isWorking = True
            except RuntimeError:
                runtime_error = True
            except TypeError:
                raise TypeError("Standard output function is not configured")
        if not self.pwd:
            if runtime_error and not self.stdout():
                self.refresh(f"/home/{self.user}")
            else:
                self.pwd = self.stdout('pwd')
                self.refresh(self.pwd)
        if not self.user:
            self.user = "www-data"

    def refresh(self, pwd):
        self.machine = f"{self.user}@machine:{pwd}# "

    def start(self):
        while True:
            user_input = self.stdin().strip(' ')
            if user_input.startswith('cd '):
                temporary = user_input.split('cd ')[-1].strip(' ')
                if '/' in temporary and temporary.startswith('/'):
                    self.pwd = temporary
                else:
                    self.pwd = path_join(self.pwd, temporary)
                self.refresh(self.pwd)
            try:
                with timeout(self.stdout_timeout, exception=RuntimeError):
                    data = self.stdout(user_input)
                    if data:
                        print(data)
            except RuntimeError:
                print(f"machine: {user_input}: command not found")
