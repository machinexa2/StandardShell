Library to help form shell
